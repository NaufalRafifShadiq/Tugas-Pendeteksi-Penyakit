<?php
session_start();

// Data user dummy
$valid_username = "admin";
$valid_password = "12345";

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi login
if ($username === $valid_username && $password === $valid_password) {
    $_SESSION['username'] = $username;
    header("Location: dashboard.php");
    exit();
} else {
    echo "<script>alert('Username atau password salah!');window.location='index.html';</script>";
}
?>
