<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$hasil = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gejala = strtolower($_POST['gejala'] ?? '');

    if (strpos($gejala, 'demam') !== false && strpos($gejala, 'batuk') !== false) {
        $hasil = "Kemungkinan Anda terkena Flu atau Infeksi Saluran Pernapasan.";
    } elseif (strpos($gejala, 'mual') !== false || strpos($gejala, 'sakit perut') !== false) {
        $hasil = "Kemungkinan Anda mengalami gangguan pencernaan.";
    } elseif (strpos($gejala, 'pusing') !== false && strpos($gejala, 'lemas') !== false) {
        $hasil = "Kemungkinan Anda mengalami anemia atau tekanan darah rendah.";
    } else {
        $hasil = "Gejala tidak dikenali. Silakan konsultasikan ke dokter.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Deteksi Penyakit</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Selamat Datang, <?= htmlspecialchars($_SESSION['username']) ?>!</h2>
    <a href="logout.php" style="float:right; color:red;">Logout</a>

    <form method="POST" action="">
        <label for="gejala">Masukkan Gejala Anda:</label>
        <textarea name="gejala" rows="4" required></textarea>
        <button type="submit">Deteksi</button>
    </form>

    <?php if ($hasil): ?>
        <div class="result">
            <strong>Hasil Deteksi:</strong>
            <p><?= $hasil ?></p>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
